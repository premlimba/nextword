from flask import Flask, render_template, request
import model as model
app = Flask(__name__)

@app.route('/', methods=['GET'])
def index():
    return render_template('index.html')

@app.route('/operation_result', methods=['POST']) # type: ignore
def operation_result():
    inp = request.form['Input1']
    res = model.model_run(inp)
    return render_template('index.html',result=res)

if __name__=='__main__':
    app.debug = True
    app.run()
